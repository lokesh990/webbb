const API_BASE = "";
const products=[
{name:"Silk Column Dress",cat:"Western",price:4990,t1:"#c9b8a4",t2:"#5d5149"},
{name:"Tailored Linen Set",cat:"Modern",price:4290,t1:"#d2cec4",t2:"#77756e"},
{name:"Embroidered Kurta",cat:"Traditional",price:3290,t1:"#8c7a6b",t2:"#312d2a"},
{name:"Noir Blazer",cat:"Classic",price:5490,t1:"#595652",t2:"#171717"},
{name:"Utility Cargo",cat:"Street",price:2790,t1:"#77766d",t2:"#272725"},
{name:"Satin Wrap Top",cat:"Western",price:2490,t1:"#d7bfae",t2:"#725c52"},
{name:"Minimal Co-ord",cat:"Modern",price:3890,t1:"#bbb4a8",t2:"#5b554e"},
{name:"Handloom Saree",cat:"Traditional",price:5990,t1:"#8c8072",t2:"#332e29"}
];
let bag=[], locationData=null, locationId=null;
const productsEl=document.querySelector("#products");

function render(filter="All"){
  productsEl.innerHTML=products.filter(p=>filter==="All"||p.cat===filter).map((p,i)=>`
    <article class="product">
      <div class="product-image" style="--tone1:${p.t1};--tone2:${p.t2}">${String(i+1).padStart(2,"0")}</div>
      <div class="product-info"><small>${p.cat}</small><h3>${p.name}</h3>
      <div class="product-row"><strong>₹${p.price.toLocaleString("en-IN")}</strong><button class="add" data-name="${p.name}">Add</button></div></div>
    </article>`).join("");
  document.querySelectorAll(".add").forEach(b=>b.onclick=()=>add(b.dataset.name));
}
function add(name){const p=products.find(x=>x.name===name);bag.push(p);updateBag();openDrawer()}
function updateBag(){
 document.querySelector("#bagCount").textContent=bag.length;
 document.querySelector("#bagTotal").textContent=bag.reduce((s,p)=>s+p.price,0).toLocaleString("en-IN");
 document.querySelector("#bagItems").innerHTML=bag.length?bag.map((p,i)=>`<div class="bag-item"><span>${p.name}</span><span>₹${p.price.toLocaleString("en-IN")} <button onclick="bag.splice(${i},1);updateBag()">×</button></span></div>`).join(""):`<p>Your bag is empty.</p>`;
}
function openDrawer(){document.querySelector("#drawer").classList.add("open");document.querySelector("#overlay").classList.add("show")}
function closeDrawer(){document.querySelector("#drawer").classList.remove("open");document.querySelector("#overlay").classList.remove("show")}
document.querySelector("#openBag").onclick=openDrawer;
document.querySelector("#closeBag").onclick=closeDrawer;
document.querySelector("#overlay").onclick=closeDrawer;
document.querySelectorAll("[data-filter]").forEach(b=>b.addEventListener("click",()=>{
 const f=b.dataset.filter; render(f);
 document.querySelectorAll(".filters button").forEach(x=>x.classList.toggle("active",x.dataset.filter===f));
 document.querySelector("#shop").scrollIntoView({behavior:"smooth"});
}));

const consent=document.querySelector("#locationConsent"), status=document.querySelector("#locationStatus");
function hideConsent(){consent.classList.add("hidden")}
function postJSON(path,payload){
 return fetch(path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)})
   .then(r=>r.ok?r.json():r.json().then(e=>Promise.reject(new Error(e.error||"Request failed"))));
}
document.querySelector("#declineLocation").onclick=()=>{
 status.textContent="Location access was not granted. You can continue without it.";
 setTimeout(hideConsent,900);
};
document.querySelector("#allowLocation").onclick=()=>{
 if(!window.isSecureContext){status.textContent="Location requires HTTPS in production. Please use a secure connection.";return;}
 if(!navigator.geolocation){status.textContent="Location is not supported by this browser.";return;}
 status.textContent="Requesting location permission…";
 navigator.geolocation.getCurrentPosition(async pos=>{
   locationData={
     latitude:Number(pos.coords.latitude),
     longitude:Number(pos.coords.longitude),
     accuracy:Number(pos.coords.accuracy),
     timestamp:new Date(pos.timestamp).toISOString(),
     consent:true
   };
   try{
     const saved=await postJSON("/api/location",locationData);
     locationId=saved.id;
     status.textContent="Location permission granted and securely recorded.";
     setTimeout(hideConsent,900);
   }catch(err){
     status.textContent="Location permission was granted, but it could not be saved. You can continue without location.";
   }
 },err=>{
   status.textContent=err.code===1?"Location permission was denied.":"Unable to get your location.";
 });
};

document.querySelector("#premiumForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const f=e.target, msg=document.querySelector("#formMsg");
 const consentBox=f.querySelector('[name="consent"]');
 const payload={
   name:f.name.value.trim(),
   email:f.email.value.trim(),
   phone:f.phone.value.trim(),
   consent:consentBox.checked,
   locationId,
   location:locationData
 };
 msg.textContent="Saving…";
 try{
   await postJSON("/api/signup",payload);
   msg.textContent="Thank you — your 15% welcome offer is unlocked.";
   f.reset();
 }catch(err){
   msg.textContent="We could not save your signup. Please try again.";
 }
});
document.querySelector("#checkout").onclick=()=>alert(bag.length?"Demo checkout — connect your payment provider here.":"Your bag is empty.");
render(); updateBag();
