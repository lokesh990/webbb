# VÉRA — integrated consent-based location + signup website

This project combines the VÉRA recreated storefront with consent-based location capture and a Node/Express backend.

## Included
- Responsive VÉRA storefront, filters, bag drawer and premium signup form.
- On first page load, a clear location consent dialog is shown.
- Browser precise location is requested only after the visitor clicks **Allow location**.
- When permission is granted, latitude/longitude/accuracy/timestamp are sent to the backend.
- Signup stores name, email, phone and the linked consented location.
- Private `/admin` dashboard for viewing signup and location records.
- JSON storage in `data/` for simple deployment.

## Run locally
1. Install Node.js 18+.
2. In this folder run `npm install`.
3. Set a strong admin secret:
   - PowerShell: `$env:ADMIN_TOKEN="use-a-long-random-secret"`
   - macOS/Linux: `export ADMIN_TOKEN="use-a-long-random-secret"`
4. Run `npm start`.
5. Open `http://localhost:3000`.
6. Admin dashboard: `http://localhost:3000/admin` and enter the same admin token.

## Production
Use HTTPS. Browser geolocation is restricted to secure contexts in production.
Deploy this whole folder on a Node.js-capable host. A static-only host such as Shipstatic cannot run `server.js`.
Put the site behind HTTPS and keep `ADMIN_TOKEN` only as a server environment variable.

## Privacy
The location dialog explains that precise location is optional and only requested after the visitor chooses Allow. The signup form separately asks for consent to store the submitted details for VÉRA offers/updates. Publish a privacy notice that accurately states your purpose, retention, access, deletion and other legally required information for your users.

## Storage
Records are written to:
- `data/locations.json`
- `data/signups.json`

For a larger production deployment, replace JSON files with a managed database and add proper admin authentication, encryption, retention/deletion controls and audit logging.
