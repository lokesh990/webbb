const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

if (!ADMIN_TOKEN) {
  console.warn("WARNING: Set ADMIN_TOKEN before exposing this server publicly.");
}

const DATA_DIR = path.join(__dirname, "data");
const DB = path.join(DATA_DIR, "signups.json");
const LOCATIONS = path.join(DATA_DIR, "locations.json");

fs.mkdirSync(DATA_DIR, {recursive:true});
for (const file of [DB, LOCATIONS]) {
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]", "utf8");
}

app.disable("x-powered-by");
app.use(express.json({limit:"20kb"}));
app.use(express.static(__dirname, {index:"index.html"}));

function read(file){return JSON.parse(fs.readFileSync(file,"utf8"))}
function write(file,data){fs.writeFileSync(file,JSON.stringify(data,null,2),"utf8")}
function clean(value,max=500){return String(value ?? "").trim().slice(0,max)}
function validEmail(email){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)}
function validLocation(loc){
  return loc && loc.consent === true &&
    Number.isFinite(Number(loc.latitude)) && Number(loc.latitude)>=-90 && Number(loc.latitude)<=90 &&
    Number.isFinite(Number(loc.longitude)) && Number(loc.longitude)>=-180 && Number(loc.longitude)<=180 &&
    Number.isFinite(Number(loc.accuracy)) && Number(loc.accuracy)>=0;
}

app.post("/api/location",(req,res)=>{
  if (!validLocation(req.body)) return res.status(400).json({error:"Valid consented location is required"});
  const rows=read(LOCATIONS);
  const record={
    id:`loc_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
    latitude:Number(req.body.latitude),
    longitude:Number(req.body.longitude),
    accuracy:Number(req.body.accuracy),
    capturedAt:new Date().toISOString(),
    consent:true
  };
  rows.push(record); write(LOCATIONS,rows);
  res.json({ok:true,id:record.id});
});

app.post("/api/signup",(req,res)=>{
  const name=clean(req.body?.name,120);
  const email=clean(req.body?.email,254).toLowerCase();
  const phone=clean(req.body?.phone,40);
  const consent=req.body?.consent===true;
  if(!name||!validEmail(email)||!phone||!consent)
    return res.status(400).json({error:"Name, valid email, phone and signup consent are required"});

  let location=null;
  if(req.body.locationId){
    location=read(LOCATIONS).find(x=>x.id===clean(req.body.locationId,100))||null;
  }
  if(!location && validLocation(req.body.location)){
    // Fallback if the location was granted but the location record was not linked.
    location={
      id:`loc_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
      latitude:Number(req.body.location.latitude),
      longitude:Number(req.body.location.longitude),
      accuracy:Number(req.body.location.accuracy),
      capturedAt:new Date().toISOString(),
      consent:true
    };
    const locations=read(LOCATIONS); locations.push(location); write(LOCATIONS,locations);
  }

  const rows=read(DB);
  const record={
    id:`signup_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
    name,email,phone,
    consent:true,
    consentAt:new Date().toISOString(),
    locationId:location?.id||null,
    location:location||null
  };
  rows.push(record); write(DB,rows);
  res.json({ok:true,id:record.id});
});

function requireAdmin(req,res,next){
  if(!ADMIN_TOKEN || req.get("x-admin-token")!==ADMIN_TOKEN)
    return res.status(401).json({error:"Unauthorized"});
  next();
}
app.get("/api/signups",requireAdmin,(req,res)=>res.json(read(DB)));
app.get("/api/locations",requireAdmin,(req,res)=>res.json(read(LOCATIONS)));
app.get("/admin",requireAdmin,(req,res)=>res.sendFile(path.join(__dirname,"admin","index.html")));
app.get("/health",(req,res)=>res.json({ok:true}));

app.listen(PORT,()=>console.log(`VÉRA server listening on port ${PORT}`));
